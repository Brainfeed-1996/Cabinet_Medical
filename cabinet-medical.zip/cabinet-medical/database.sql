CREATE DATABASE
IF NOT EXISTS cabinet_medical;
USE cabinet_medical;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR
(100) NOT NULL UNIQUE,
    username VARCHAR
(50) NOT NULL UNIQUE,
    password VARCHAR
(100) NOT NULL,
    phone VARCHAR
(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    validation_token VARCHAR
(100),
    is_validated BOOLEAN DEFAULT FALSE
);

CREATE TABLE doctors (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR
(50) NOT NULL,
    speciality VARCHAR
(50) NOT NULL
);

CREATE TABLE appointments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    doctor_id INT,
    appointment_date DATETIME NOT NULL,
    reason TEXT,
    is_first_visit BOOLEAN DEFAULT TRUE,
    status ENUM
('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY
(user_id) REFERENCES users
(id),
    FOREIGN KEY
(doctor_id) REFERENCES doctors
(id)
);

CREATE TABLE time_slots (
    id INT PRIMARY KEY AUTO_INCREMENT,
    doctor_id INT,
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    is_available BOOLEAN DEFAULT TRUE,
    FOREIGN KEY
(doctor_id) REFERENCES doctors
(id)
); 